import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Paystack proxy route
app.use(express.json());

app.post('/api/paystack/charge', async (req, res) => {
  const { email, amount, currency } = req.body;
  // In a real application, you would use axios or fetch to call the Paystack API
  // using process.env.PAYSTACK_SECRET_KEY
  res.json({ status: 'success', message: 'Mock Paystack proxy response' });
});

// For development in AI Studio, mount Vite's dev middleware
import { createServer } from 'vite';

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
